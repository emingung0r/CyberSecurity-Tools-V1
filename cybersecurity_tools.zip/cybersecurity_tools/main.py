# main.py
from interface import clear_screen, print_header
from stages import reconnaissance,scanning,privilege_escalation
import datetime

def write_report(results):
    """Writes the report to a file.
    Raporu bir dosyaya yazar."""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    filename = f"cybersecurity_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    
    try:
        with open(filename, "w", encoding="utf-8") as file:
            file.write("==================================================\n") # Başlangıç çizgisi
            file.write(f"Tarih/Saat: {timestamp}\n\n") # Tarih/saat bilgisi
            if not results:
                file.write("No actions performed.\n")
            else:
                for result in results:
                    file.write(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n")
                    file.write(f"**1. Adım: {result['stage'].upper()}**\n") # Aşama başlığı (büyük harflerle)
                    file.write(f"**Araç: {result['tool']}**\n") # Araç başlığı
                    file.write(f"Hedef: {result['target']}\n") # Hedef
                    if result["arguments"]:
                        file.write(f"Kullanılan Parametreler: {result['arguments']}\n") # Parametreler
                    file.write("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n") # Bitiş çizgisi
                    file.write("Nmap Çıktısı:\n") # Çıktı başlığı
                    file.write(result['result']) # Nmap çıktısı
                    file.write("==================================================\n\n") # Bölüm sonu çizgisi

        print(f"Report saved to {filename}")
    except Exception as e:
        print(f"Error writing report: {e}")

# ... (main_menu ve while döngüsü aynı kalıyor)