# araclar/__init__.py
# Boş bırakılabilir veya paketle ilgili kodlar eklenebilir.